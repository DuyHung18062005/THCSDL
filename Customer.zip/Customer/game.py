import pygame
import random

# Khởi tạo Pygame
pygame.init()

# Kích thước cửa sổ
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("RPG Battle Game")

# Màu sắc
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)

# Nhân vật
player_size = 50
player_x = WIDTH // 2
player_y = HEIGHT // 2
player_speed = 5
player_hp = 100

# Quái vật
enemy_size = 50
enemy_x = random.randint(100, WIDTH - 100)
enemy_y = random.randint(100, HEIGHT - 100)
enemy_hp = 50

# Vòng lặp game
running = True
while running:
    pygame.time.delay(30)
    screen.fill(WHITE)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    # Điều khiển nhân vật
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and player_x > 0:
        player_x -= player_speed
    if keys[pygame.K_RIGHT] and player_x < WIDTH - player_size:
        player_x += player_speed
    if keys[pygame.K_UP] and player_y > 0:
        player_y -= player_speed
    if keys[pygame.K_DOWN] and player_y < HEIGHT - player_size:
        player_y += player_speed
    
    # Kiểm tra va chạm
    if abs(player_x - enemy_x) < player_size and abs(player_y - enemy_y) < player_size:
        enemy_hp -= 10
        if enemy_hp <= 0:
            enemy_x = random.randint(100, WIDTH - 100)
            enemy_y = random.randint(100, HEIGHT - 100)
            enemy_hp = 50
    
    # Vẽ nhân vật
    pygame.draw.rect(screen, BLUE, (player_x, player_y, player_size, player_size))
    pygame.draw.rect(screen, RED, (enemy_x, enemy_y, enemy_size, enemy_size))
    
    pygame.display.update()

pygame.quit()
