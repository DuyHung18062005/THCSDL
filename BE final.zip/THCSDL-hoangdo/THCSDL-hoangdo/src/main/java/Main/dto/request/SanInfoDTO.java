package Main.dto.request;

public class SanInfoDTO {
    private String tenSan;
    private String loaiSan;
    private String tenChiNhanh;
    private Long giaSan;

    // No-args constructor
    public SanInfoDTO() {
    }

    // 3-args constructor (tenSan, loaiSan, tenChiNhanh)
    public SanInfoDTO(String tenSan, String loaiSan, String tenChiNhanh) {
        this.tenSan = tenSan;
        this.loaiSan = loaiSan;
        this.tenChiNhanh = tenChiNhanh;
    }

    // 4-args constructor (loaiSan, tenChiNhanh, tenSan, giaSan)
    public SanInfoDTO(String loaiSan, String tenChiNhanh, String tenSan, Long giaSan) {
        this.tenSan = tenSan;
        this.loaiSan = loaiSan;
        this.tenChiNhanh = tenChiNhanh;
        this.giaSan = giaSan;
    }

    public String getTenSan() {
        return tenSan;
    }

    public void setTenSan(String tenSan) {
        this.tenSan = tenSan;
    }

    public String getLoaiSan() {
        return loaiSan;
    }

    public void setLoaiSan(String loaiSan) {
        this.loaiSan = loaiSan;
    }

    public String getTenChiNhanh() {
        return tenChiNhanh;
    }

    public void setTenChiNhanh(String tenChiNhanh) {
        this.tenChiNhanh = tenChiNhanh;
    }

    public Long getGiaSan() {
        return giaSan;
    }

    public void setGiaSan(Long giaSan) {
        this.giaSan = giaSan;
    }
}
