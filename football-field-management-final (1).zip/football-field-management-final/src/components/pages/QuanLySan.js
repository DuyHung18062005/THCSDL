import React, { useState, useEffect } from 'react';
import '../../styles/QuanLySan.css';

const QuanLySan = () => {
  const [sanList, setSanList] = useState([
    { tenSan: "Sân A", giaThue: 200000 },
    { tenSan: "Sân B", giaThue: 250000 },
    { tenSan: "Sân C", giaThue: 180000 }
  ]);

  const [datSanList, setDatSanList] = useState([
    { tenKhachHang: "Nguyễn Văn A", tenSan: "Sân A", thoiGian: "08:00 - 09:00 23/04/2025", trangThai: "Đã đặt" },
    { tenKhachHang: "Trần Thị B", tenSan: "Sân B", thoiGian: "09:00 - 10:00 23/04/2025", trangThai: "Đã thanh toán" },
    { tenKhachHang: "Lê Văn C", tenSan: "Sân C", thoiGian: "10:00 - 11:00 23/04/2025", trangThai: "Hủy" }
  ]);

  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    tenSan: '',
    giaThue: ''
  });

  const toggleForm = () => {
    setShowForm(!showForm);
  };

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData({
      ...formData,
      [id]: value
    });
  };

  const themSan = () => {
    const { tenSan, giaThue } = formData;
    
    if (!tenSan || !giaThue) {
      alert("Vui lòng nhập đầy đủ thông tin!");
      return;
    }

    setSanList([...sanList, { tenSan, giaThue: Number(giaThue) }]);
    
    // Reset form
    setFormData({
      tenSan: '',
      giaThue: ''
    });
  };

  const xoaSan = (index) => {
    if (window.confirm("Bạn có chắc muốn xóa sân này?")) {
      const newList = [...sanList];
      newList.splice(index, 1);
      setSanList(newList);
    }
  };

  const suaSan = (index) => {
    const san = sanList[index];
    const tenMoi = prompt("Sửa tên sân:", san.tenSan);
    const giaMoi = prompt("Sửa giá thuê:", san.giaThue);

    if (tenMoi !== null && giaMoi !== null) {
      const newList = [...sanList];
      newList[index] = { tenSan: tenMoi, giaThue: Number(giaMoi) };
      setSanList(newList);
    }
  };

  return (
    <div className="container">
      <div className="title">Quản lý sân</div>
      <button onClick={toggleForm}>+ Thêm sân</button>

      {showForm && (
        <div className="form-add">
          <input 
            type="text" 
            id="tenSan" 
            placeholder="Tên sân" 
            value={formData.tenSan}
            onChange={handleInputChange}
          />
          <input 
            type="number" 
            id="giaThue" 
            placeholder="Giá thuê" 
            value={formData.giaThue}
            onChange={handleInputChange}
          />
          <button onClick={themSan}>Lưu</button>
        </div>
      )}

      <table>
        <thead>
          <tr>
            <th>Tên sân</th>
            <th>Giá thuê sân</th>
            <th>Thao tác</th>
          </tr>
        </thead>
        <tbody>
          {sanList.map((san, index) => (
            <tr key={index}>
              <td>{san.tenSan}</td>
              <td>{san.giaThue.toLocaleString('vi-VN')} VND</td>
              <td>
                <button className="action-btn" onClick={() => suaSan(index)}>Sửa</button>
                <button className="action-btn" onClick={() => xoaSan(index)}>Xóa</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="title">Quản lý đặt sân</div>
      <table>
        <thead>
          <tr>
            <th>Tên khách hàng</th>
            <th>Tên sân</th>
            <th>Thời gian</th>
            <th>Trạng thái</th>
          </tr>
        </thead>
        <tbody>
          {datSanList.map((dat, index) => (
            <tr key={index}>
              <td>{dat.tenKhachHang}</td>
              <td>{dat.tenSan}</td>
              <td>{dat.thoiGian}</td>
              <td className={dat.trangThai.toLowerCase().replace(/\s/g, '-')}>{dat.trangThai}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default QuanLySan;
