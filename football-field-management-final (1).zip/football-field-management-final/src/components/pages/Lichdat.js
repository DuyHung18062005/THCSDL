import React from 'react';
import '../../styles/Lichdat.css';

const Lichdat = () => {
  // Sample data - in a real app, this would come from an API or state
  const bookings = [
    {
      id: 1,
      name: 'Nguyễn Văn A',
      phone: '0987654321',
      field: 'Sân 5 người',
      date: '2023-05-15',
      time: '18:00 - 19:00',
      status: 'Đã xác nhận'
    },
    {
      id: 2,
      name: 'Trần Văn B',
      phone: '0123456789',
      field: 'Sân 7 người',
      date: '2023-05-16',
      time: '19:00 - 20:00',
      status: 'Chờ xác nhận'
    }
  ];

  return (
    <div className="lichdat-container">
      <h1 className="lichdat-title">Quản Lý Lịch Đặt Sân</h1>
      
      <div className="lichdat-search">
        <input type="text" placeholder="Tìm kiếm theo tên hoặc số điện thoại" />
        <button>Tìm kiếm</button>
      </div>
      
      <div className="lichdat-table">
        <table>
          <thead>
            <tr>
              <th>STT</th>
              <th>Họ và tên</th>
              <th>Số điện thoại</th>
              <th>Sân</th>
              <th>Ngày đặt</th>
              <th>Giờ đặt</th>
              <th>Trạng thái</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map((booking, index) => (
              <tr key={booking.id}>
                <td>{index + 1}</td>
                <td>{booking.name}</td>
                <td>{booking.phone}</td>
                <td>{booking.field}</td>
                <td>{booking.date}</td>
                <td>{booking.time}</td>
                <td className={booking.status === 'Đã xác nhận' ? 'confirmed' : 'pending'}>
                  {booking.status}
                </td>
                <td>
                  <button className="edit-btn">Sửa</button>
                  <button className="cancel-btn">Hủy</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className="lichdat-info">
        <h2>Lưu ý:</h2>
        <ul>
          <li>Lịch đặt sân chỉ có hiệu lực sau khi được xác nhận.</li>
          <li>Vui lòng hủy lịch đặt trước ít nhất 2 giờ nếu không thể tham gia.</li>
          <li>Mọi thắc mắc xin liên hệ: <strong>0969272243</strong></li>
        </ul>
      </div>
    </div>
  );
};

export default Lichdat;
