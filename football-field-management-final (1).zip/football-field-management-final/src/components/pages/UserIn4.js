import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../../styles/UserIn4.css";

function UserIn4() {
  const navigate = useNavigate();
  const [username, setUsername] = useState([{ nameuser: "Tran Duy" }]);
  const [userData, setUserData] = useState({
    name: "Đang tải...",
    phone: "Đang tải...",
    email: "Đang tải...",
    userId: "Đang tải...",
  });
  const [menuOpen, setMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  useEffect(() => {
    // Simulate loading user data
    const fakeData = {
      name: "Tran Duy",
      phone: "0123456789",
      email: "tranduy@example.com",
      userId: "USER123456",
    };

    // Simulate API call
    setTimeout(() => {
      setUserData(fakeData);
    }, 500);
  }, []);

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  const toggleUser = () => {
    setUserMenuOpen(!userMenuOpen);
  };

  return (
    <div className="user-info-page">
      <div
        className={`layout1 ${menuOpen ? "show" : ""}`}
        onClick={toggleMenu}
      ></div>
      <div
        className={`layout2 ${userMenuOpen ? "show" : ""}`}
        onClick={toggleUser}
      ></div>

      <div className="user-card-container">
        <div className="user-card">
          <h2>Thông tin cá nhân:</h2>
          <div className="user-info">
            <span className="label">-Họ tên:</span>{" "}
            <span id="name">{userData.name}</span>
          </div>
          <div className="user-info">
            <span className="label">-Số điện thoại:</span>{" "}
            <span id="phone">{userData.phone}</span>
          </div>
          <div className="user-info">
            <span className="label">-Email:</span>{" "}
            <span id="email">{userData.email}</span>
          </div>
          <div className="user-info">
            <span className="label userId">-Mã người dùng:</span>{" "}
            <span id="userId" className="userId">
              {userData.userId}
            </span>
          </div>
        </div>
        <div className="user-card-left"></div>
      </div>

      <footer>
        <div className="footer-container">
          <div className="footer-info">
            <h3>Liên hệ</h3>
            <p>🏠 Địa chỉ: Phòng 303, tòa B1, Đại học Bách Khoa Hà Nội</p>
            <p>
              📞 Điện thoại: <a href="tel:0969272243">0969272243</a>
            </p>
            <p>
              ✉️ Email:{" "}
              <a href="mailto:tranvanduy2k5gtc@gmail.com">
                tranvanduy2k5gtc@gmail.com
              </a>
            </p>
          </div>
          <div className="footer-social">
            <h3>Kết nối với chúng tôi</h3>
            <a href="#" className="social-icon">
              <i className="fa-brands fa-facebook"></i> Facebook
            </a>
            <a href="#" className="social-icon">
              <i className="fa-brands fa-instagram"></i> Instagram
            </a>
            <a href="#" className="social-icon">
              <i className="fa-brands fa-twitter"></i> Twitter
            </a>
          </div>
        </div>
        <p className="footer-copy">
          © 2025 Sân bóng D2HT. All Rights Reserved.
        </p>
      </footer>
    </div>
  );
}

export default UserIn4;
