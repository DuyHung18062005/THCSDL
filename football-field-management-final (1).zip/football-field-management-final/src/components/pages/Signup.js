import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../../styles/Signup.css";

const Signup = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: "",
    password: "",
    confirmPassword: "",
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData({
      ...formData,
      [id === "signin-name"
        ? "username"
        : id === "signin-pass"
        ? "password"
        : id === "signin-pass-again"
        ? "confirmPassword"
        : id]: value,
    });
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.username.trim()) {
      newErrors.username = "Vui lòng nhập tên đăng nhập";
    }

    if (!formData.password) {
      newErrors.password = "Vui lòng nhập mật khẩu";
    }

    if (!formData.confirmPassword) {
      newErrors.confirmPassword = "Vui lòng nhập lại mật khẩu";
    } else if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Mật khẩu không khớp";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (validateForm()) {
      // In a real app, you would send the data to your backend
      console.log("Form submitted:", formData);

      // Redirect to signin page after successful signup
      alert("Đăng ký thành công! Vui lòng đăng nhập.");
      navigate("/signin");
    }
  };

  return (
    <div className="signup-container">
      <div className="signup-container-left">
        {/* Background image is set in CSS */}
      </div>
      <div className="signup-container-right">
        <div className="signup-form-wrapper">
          <h1 className="signup-title">Đăng ký</h1>
          <form onSubmit={handleSubmit}>
            <div className="signup-info">
              <label htmlFor="signin-name"></label>
              <input
                type="text"
                id="signin-name"
                className={`signin-name ${
                  errors.username ? "input-error" : ""
                }`}
                placeholder="Tên đăng nhập"
                value={formData.username}
                onChange={handleChange}
                required
              />
              {errors.username && (
                <div className="error-message">{errors.username}</div>
              )}

              <label htmlFor="signin-pass"></label>
              <input
                type="password"
                id="signin-pass"
                className={`signin-pass ${
                  errors.password ? "input-error" : ""
                }`}
                placeholder="Mật khẩu"
                value={formData.password}
                onChange={handleChange}
                required
              />
              {errors.password && (
                <div className="error-message">{errors.password}</div>
              )}

              <label htmlFor="signin-pass-again"></label>
              <input
                type="password"
                id="signin-pass-again"
                className={`signin-pass-again ${
                  errors.confirmPassword ? "input-error" : ""
                }`}
                placeholder="Nhập lại mật khẩu"
                value={formData.confirmPassword}
                onChange={handleChange}
                required
              />
              {errors.confirmPassword && (
                <div className="error-message">{errors.confirmPassword}</div>
              )}
            </div>
            <div className="signup-btn">
              <button type="submit">Xác nhận đăng ký</button>
              <button type="button">
                <Link className="btn-signin" to="/signin">
                  Quay lại trang đăng nhập
                </Link>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Signup;
