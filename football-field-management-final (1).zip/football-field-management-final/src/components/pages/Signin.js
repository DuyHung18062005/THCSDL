import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../../styles/Signin.css";

const Signin = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData({
      ...formData,
      [id === "signin-name"
        ? "username"
        : id === "signin-pass"
        ? "password"
        : id]: value,
    });
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.username.trim()) {
      newErrors.username = "Vui lòng nhập tên đăng nhập";
    }

    if (!formData.password) {
      newErrors.password = "Vui lòng nhập mật khẩu";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (validateForm()) {
      // In a real app, you would authenticate with your backend
      console.log("Form submitted:", formData);

      // Simulate successful login
      if (formData.username === "admin" && formData.password === "admin") {
        navigate("/manager"); // Redirect to manager dashboard
      } else {
        navigate("/"); // Redirect to customer home page
      }
    }
  };

  return (
    <div className="signin-container">
      <div className="signin-container-left">
        {/* Background image is set in CSS */}
      </div>
      <div className="signin-container-right">
        <div className="signin-form-wrapper">
          <h1 className="signin-title">Đăng nhập</h1>
          <form onSubmit={handleSubmit}>
            <div className="signin-info">
              <label htmlFor="signin-name"></label>
              <input
                type="text"
                id="signin-name"
                className={`signin-name ${
                  errors.username ? "input-error" : ""
                }`}
                placeholder="Tên đăng nhập"
                value={formData.username}
                onChange={handleChange}
                required
              />
              {errors.username && (
                <div className="error-message">{errors.username}</div>
              )}

              <label htmlFor="signin-pass"></label>
              <input
                type="password"
                id="signin-pass"
                className={`signin-pass ${
                  errors.password ? "input-error" : ""
                }`}
                placeholder="Mật khẩu"
                value={formData.password}
                onChange={handleChange}
                required
              />
              {errors.password && (
                <div className="error-message">{errors.password}</div>
              )}
            </div>
            <div className="signin-btn">
              <button type="submit">Đăng nhập</button>
              <button type="button">
                <Link className="btn-signup" to="/signup">
                  Đăng ký
                </Link>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Signin;
