import React, { useState, useEffect } from 'react';
import '../../styles/QuanLyKhachHang.css';

const QuanLyKhachHang = () => {
  const [khachHangList, setKhachHangList] = useState([
    { ten: "Nguyễn Văn A", sdt: "0912345678", email: "vana@gmail.com" },
    { ten: "Trần Thị B", sdt: "0987654321", email: "thib@gmail.com" },
    { ten: "Lê Văn C", sdt: "0909090909", email: "vanc@gmail.com" }
  ]);

  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    ten: '',
    sdt: '',
    email: ''
  });

  const toggleForm = () => {
    setShowForm(!showForm);
  };

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData({
      ...formData,
      [id]: value
    });
  };

  const themKhachHang = () => {
    const { ten, sdt, email } = formData;
    
    if (!ten || !sdt || !email) {
      alert("Vui lòng điền đầy đủ thông tin!");
      return;
    }

    setKhachHangList([...khachHangList, { ten, sdt, email }]);
    
    // Reset form
    setFormData({
      ten: '',
      sdt: '',
      email: ''
    });
  };

  const xoaKhachHang = (index) => {
    if (window.confirm("Bạn có chắc muốn xóa khách hàng này?")) {
      const newList = [...khachHangList];
      newList.splice(index, 1);
      setKhachHangList(newList);
    }
  };

  const suaKhachHang = (index) => {
    const kh = khachHangList[index];
    const tenMoi = prompt("Tên khách hàng:", kh.ten);
    const sdtMoi = prompt("Số điện thoại:", kh.sdt);
    const emailMoi = prompt("Email:", kh.email);

    if (tenMoi && sdtMoi && emailMoi) {
      const newList = [...khachHangList];
      newList[index] = { ten: tenMoi, sdt: sdtMoi, email: emailMoi };
      setKhachHangList(newList);
    }
  };

  return (
    <div className="container">
      <div className="title">Quản lý khách hàng</div>
      <button onClick={toggleForm}>+ Thêm khách hàng</button>

      {showForm && (
        <div className="form-add">
          <input 
            type="text" 
            id="ten" 
            placeholder="Tên khách hàng" 
            value={formData.ten}
            onChange={handleInputChange}
          />
          <input 
            type="tel" 
            id="sdt" 
            placeholder="Số điện thoại" 
            value={formData.sdt}
            onChange={handleInputChange}
          />
          <input 
            type="email" 
            id="email" 
            placeholder="Thông tin mail" 
            value={formData.email}
            onChange={handleInputChange}
          />
          <button onClick={themKhachHang}>Lưu</button>
        </div>
      )}

      <table>
        <thead>
          <tr>
            <th>Tên khách hàng</th>
            <th>Số điện thoại</th>
            <th>Mail</th>
            <th>Thao tác</th>
          </tr>
        </thead>
        <tbody>
          {khachHangList.map((kh, index) => (
            <tr key={index}>
              <td>{kh.ten}</td>
              <td>{kh.sdt}</td>
              <td>{kh.email}</td>
              <td>
                <button className="action-btn" onClick={() => suaKhachHang(index)}>Sửa</button>
                <button className="action-btn" onClick={() => xoaKhachHang(index)}>Xóa</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default QuanLyKhachHang;
