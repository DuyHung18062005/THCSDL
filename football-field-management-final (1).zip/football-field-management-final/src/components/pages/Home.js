import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import "../../styles/Home.css";

const Home = () => {
  const [searchName, setSearchName] = useState("");
  const [searchArea, setSearchArea] = useState("");
  const [filteredFields, setFilteredFields] = useState([]);
  const [showOverlay, setShowOverlay] = useState(false);
  const [selectedField, setSelectedField] = useState(null);
  const [branches, setBranches] = useState([]);

  // Mock data for football fields
  const danhSachSan = [
    {
      ten: "Sân Mỹ Đình",
      chinhanh: "Hà Nội",
      diaChi: "Đường Lê Đức Thọ, Nam Từ Liêm, Hà Nội",
      gia: "500.000đ/giờ",
    },
    {
      ten: "Sân Hàng Đẫy",
      chinhanh: "Hà Nội",
      diaChi: "Số 29 Hàng Đẫy, Đống Đa, Hà Nội",
      gia: "450.000đ/giờ",
    },
    {
      ten: "Sân Thống Nhất",
      chinhanh: "Hồ Chí Minh",
      diaChi: "138 Đường Nguyễn Thị Minh Khai, Quận 1, TP.HCM",
      gia: "550.000đ/giờ",
    },
    {
      ten: "Sân Pleiku",
      chinhanh: "Gia Lai",
      diaChi: "Đường Trường Chinh, TP. Pleiku, Gia Lai",
      gia: "350.000đ/giờ",
    },
  ];

  useEffect(() => {
    // Initialize with all fields
    setFilteredFields(danhSachSan);

    // Extract unique branches for the dropdown
    const uniqueBranches = [...new Set(danhSachSan.map((san) => san.chinhanh))];
    setBranches(uniqueBranches);
  }, []);

  const filterSan = () => {
    let filtered = danhSachSan;

    if (searchName) {
      filtered = filtered.filter((san) =>
        san.ten.toLowerCase().includes(searchName.toLowerCase())
      );
    }

    if (searchArea) {
      filtered = filtered.filter((san) => san.chinhanh === searchArea);
    }

    setFilteredFields(filtered);
  };

  const showFieldDetails = (field) => {
    setSelectedField(field);
    setShowOverlay(true);
  };

  const closeOverlay = () => {
    setShowOverlay(false);
  };

  // Mock function to check if a time slot is booked
  const isTimeSlotBooked = () => {
    return Math.random() < 0.3; // 30% chance of being booked
  };

  // Generate time slots for the selected field
  const generateTimeSlots = () => {
    if (!selectedField) return null;

    const days = [];
    const today = new Date();

    for (let i = 0; i < 5; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      days.push(date);
    }

    return (
      <div className="thoikhoabieu">
        {days.map((day, index) => (
          <div key={index} className="ngay">
            <h4>
              {day.toLocaleDateString("vi-VN", {
                weekday: "long",
                month: "numeric",
                day: "numeric",
              })}
            </h4>
            {[6, 8, 10, 12, 14, 16, 18, 20].map((hour, hourIndex) => {
              const booked = isTimeSlotBooked();
              return (
                <div
                  key={hourIndex}
                  className={`khunggio ${booked ? "dat" : ""}`}
                >
                  {`${hour}:00 - ${hour + 2}:00`}
                  {!booked && (
                    <button
                      className="btn-book"
                      onClick={() =>
                        bookField(
                          selectedField.ten,
                          day.toLocaleDateString(),
                          `${hour}:00 - ${hour + 2}:00`
                        )
                      }
                    >
                      Đặt sân
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    );
  };

  const bookField = (fieldName, date, timeSlot) => {
    alert(`Bạn đã đặt ${fieldName} vào ngày ${date}, khung giờ ${timeSlot}!`);
    closeOverlay();
  };

  return (
    <>
      <div className="welcome">
        <div className="welcome-left">
          <h1 className="chaomung xx">
            Chào mừng đến với sân bóng của chúng tôi!
          </h1>
          <p className="chaomung ss">
            Sân bóng D2HT là địa điểm lý tưởng dành cho những người đam mê bóng
            đá. Được thành lập bởi bốn người bạn chung chí hướng – Duy, Hoàng,
            Hưng và Tú, sân bóng không chỉ mang đến không gian rộng rãi, mặt cỏ
            chất lượng mà còn đi kèm với hệ thống đèn chiếu sáng hiện đại, phục
            vụ các trận đấu cả ban ngày lẫn ban đêm. Với tinh thần thể thao và
            mong muốn xây dựng một cộng đồng bóng đá sôi động, chủ sân luôn chú
            trọng đến chất lượng dịch vụ, đảm bảo khách hàng có những trải
            nghiệm tốt nhất. Dù là trận đấu giao hữu hay giải đấu bán chuyên,
            sân bóng D2HT luôn là sự lựa chọn hoàn hảo cho mọi đội bóng.
          </p>
          <Link to="/datsan" className="datsan-fast">
            Đặt sân ngay &gt;&gt;
          </Link>
        </div>
        <div className="welcome-right"></div>
      </div>

      <h2 className="danhsachsanbong">
        <p className="dssb">Danh sách sân bóng</p>
      </h2>

      <div className="listsearch">
        <div className="searchfield">
          <h2>Tìm kiếm sân:</h2>
          <label htmlFor="searchName">Tên sân:</label>
          <input
            type="text"
            id="searchName"
            name="searchName"
            value={searchName}
            onChange={(e) => setSearchName(e.target.value)}
          />

          <label htmlFor="searchArea">Tìm theo chi nhánh:</label>
          <select
            id="searchArea"
            name="searchArea"
            value={searchArea}
            onChange={(e) => setSearchArea(e.target.value)}
          >
            <option value="">Tất cả chi nhánh</option>
            {branches.map((branch, index) => (
              <option key={index} value={branch}>
                {branch}
              </option>
            ))}
          </select>

          <button onClick={filterSan}>Tìm kiếm</button>
        </div>

        <div className="sanbong-container">
          <div id="danhsachsan" className="sanbong">
            {filteredFields.length === 0 ? (
              <p>Không tìm thấy sân phù hợp.</p>
            ) : (
              filteredFields.map((san, index) => (
                <div key={index} className="san-item">
                  <h3>{san.ten}</h3>
                  <p>
                    <strong>Chi nhánh:</strong> {san.chinhanh}
                  </p>
                  <p>
                    <strong>Địa chỉ:</strong> {san.diaChi}
                  </p>
                  <p>
                    <strong>Giá thuê:</strong> {san.gia}
                  </p>
                  <button
                    onClick={() => showFieldDetails(san)}
                    className="btn-datsan"
                  >
                    Xem chi tiết sân
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Field details overlay */}
      {showOverlay && selectedField && (
        <div className="overlay">
          <div className="overlay-content">
            <span className="close-btn" onClick={closeOverlay}>
              &times;
            </span>
            <h2 id="tenSanOverlay">{selectedField.ten}</h2>
            <div id="sanInfoOverlay" className="san-info">
              <p>
                <strong>Chi nhánh:</strong> {selectedField.chinhanh}
              </p>
              <p>
                <strong>Địa chỉ:</strong> {selectedField.diaChi}
              </p>
              <p>
                <strong>Giá thuê:</strong> {selectedField.gia}
              </p>
            </div>
            <h3>Lịch đặt sân</h3>
            {generateTimeSlots()}
          </div>
        </div>
      )}
    </>
  );
};

export default Home;
