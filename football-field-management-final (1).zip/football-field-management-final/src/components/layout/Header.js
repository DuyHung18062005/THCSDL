import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBars, faFutbol, faHouse, faClipboard, faCalendar, faStar } from '@fortawesome/free-solid-svg-icons';
import '../../styles/Header.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  const closeMenu = () => {
    setMenuOpen(false);
  };

  return (
    <>
      <header className="nav" id="nav">
        <ul className="navbar">
          <li className="navbar-item navleft">
            <FontAwesomeIcon 
              icon={faBars} 
              className="ss" 
              onClick={toggleMenu} 
            />
            <p className="nav-sanbong" onClick={() => window.location.href='/'}>
              <FontAwesomeIcon icon={faFutbol} className="cc" />
              Sân bóng D2HT
            </p>
          </li>
          <ul className={`menu ${menuOpen ? 'show' : ''}`}>
            <li className="menu-item aa">
              <FontAwesomeIcon 
                icon={faBars} 
                className="aa" 
                onClick={toggleMenu} 
              />
              <p className="menu-item-aa">
                <FontAwesomeIcon icon={faFutbol} className="cc" />
                Sân bóng D2HT
              </p>
            </li>
            <li className="menu-item bb">
              <Link className="menu-item-bb" to="/" onClick={closeMenu}>
                <FontAwesomeIcon icon={faHouse} className="cc" />
                Trang chủ
              </Link>
            </li>
            <li className="menu-item bb">
              <Link className="menu-item-bb" to="/datsan" onClick={closeMenu}>
                <FontAwesomeIcon icon={faClipboard} className="cc" />
                Đặt Lịch Sân
              </Link>
            </li>
            <li className="menu-item bb">
              <Link className="menu-item-bb" to="/lichdat" onClick={closeMenu}>
                <FontAwesomeIcon icon={faCalendar} className="cc" />
                Quản Lý Lịch Đặt
              </Link>
            </li>
            <li className="menu-item bb">
              <Link className="menu-item-bb" to="/danhgia" onClick={closeMenu}>
                <FontAwesomeIcon icon={faStar} className="cc" />
                Đánh Giá Chất Lượng Sân
              </Link>
            </li>
          </ul>
          <li className="navbar-item">
            <Link className="nav-signout" to="/signin">Sign out</Link>
          </li>
        </ul>
      </header>
      <div 
        className={`layout ${menuOpen ? 'show' : ''}`} 
        onClick={closeMenu}
      ></div>
    </>
  );
};

export default Header;
